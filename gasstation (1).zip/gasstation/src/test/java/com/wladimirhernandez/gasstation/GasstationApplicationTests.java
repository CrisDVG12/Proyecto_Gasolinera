package com.wladimirhernandez.gasstation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GasstationApplicationTests {

	@Test
	void contextLoads() {
	}

}
